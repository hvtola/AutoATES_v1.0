import arcpy as ARCPY
import arcpy.management as DM
import os as OS
import sys as SYS
import subprocess as SUB
import arcpyWithR as RARC

#### Parameter Dictionaries ####
smoothDict = {"Regular": "regular", "Low": "low"} 

def pra():
    #### Get User Provided Inputs ####
    inputRas = ARCPY.GetParameterAsText(0)
    outPRA = ARCPY.GetParameterAsText(1)
    meanHS = ARCPY.GetParameterAsText(2)
    smoothDeg = ARCPY.GetParameterAsText(3)
    smoothDegStr = smoothDict[smoothDeg]
    mainWind = ARCPY.GetParameterAsText(4)
    mainWindTol = ARCPY.GetParameterAsText(5)
    workDir = ARCPY.GetParameterAsText(6)
    forest = ARCPY.GetParameterAsText(7)
    
    

    #### Create R Command ####
    pyScript = SYS.argv[0]
    toolDir = OS.path.dirname(pyScript)
    rScript = OS.path.join(toolDir, "pra.r")
    ARCPY.SetProgressor("default", "Executing R Script...")
    args = ["R", "--slave", "--vanilla", "--args",
            inputRas, outPRA, meanHS, smoothDeg, mainWind, mainWindTol, workDir, forest] 

    #### Uncomment Next Two Lines to Print/Create Command Line Args ####
    #cmd = RARC.createRCommand(args, rScript)
    #ARCPY.AddWarning(cmd)

    #### Execute Command ####
    scriptSource = open(rScript, 'rb')
    rCommand = SUB.Popen(args, 
                         stdin = scriptSource,
                         stdout = SUB.PIPE, 
                         stderr = SUB.PIPE,
                         shell=True)

    #### Print Result ####
    resString, errString = rCommand.communicate()

    #### Push Output to Message Window ####
    if errString and "Calculations Complete..." not in resString:
        ARCPY.AddError(errString)
    else:
        resOutString = RARC.printRMessages(resString)
        ARCPY.AddMessage(resOutString)

     #### Render the Results ####
        params = ARCPY.gp.GetParameterInfo()
        renderFile = OS.path.join(toolDir, "PRA_symbology.lyr")
        params[1].Symbology = renderFile
        #params[2].Symbology = renderFile

if __name__ == '__main__':

    test = pra() 
